package com.example.Job.Portal.Enum;

public enum ApplicationStatus {
    PENDING, SHORTLISTED, REJECTED, ACCEPTED
}
