package com.example.Job.Portal.Enum;

public enum Role {
    ADMIN, RECRUITER, CANDIDATE;

}
